#include <ucontext.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <errno.h>

typedef enum
{
    ready,
    run,
	empty,
    finish
} status_thread;

typedef struct Threads
{
	int Index_Of_Thread;
    int Required_Time_To_Execute;
    int Number_Of_Thread;
    status_thread status;
    ucontext_t context;
} Threads;

Threads **Whole_Threads;            		//all of the threads
Threads **Array_Of_Threads;           		//thread array of size 5.
int greatest_common_divisor(int x, int y);
int Find_Greatest_Common_Divisor(int arr[], int k);
void Print_Function();
void Initialization_Of_Thread();
int Creation_Of_Thread();
void Leave_Thread(int Number_Of_Thread);
void Run_Thread(int Number_Of_Thread, int totalDuration);
void Choose_Following_Thread();
void Shortest_Reamining_Time_First();
void ShortestFunction();
int Current_Thread = 1;        		   //currently executing thread number
int Following_Thread = 1;              //next thread
int Last_Thread = 1;                   //last thread
int Shares_Of_Threads[5];                   //it stores the shares of the threads
int Number_Of_Finished_Threads = 0;
int Sum_Of_Shares = 0;                 //total shares of the threads
int GreenLight = 0;                    //set if a thread leaves
int Aggregate_Threads = 0;             //number of threads + 1(main thread)

int greatest_common_divisor(int x, int y)
{
    if (x == 0)
        return y;
    return greatest_common_divisor(y % x, x);
}

int Find_Greatest_Common_Divisor(int arr[], int k)
{
    int result = arr[0];
	int i = 1;
    while (i < k)
    {
        result = greatest_common_divisor(arr[i], result);

        if(result == 1)
        {
           return 1;
        }
	i++;
    }
    return result;
}


void Print_Function()
{
    printf("running->T%d ready->", Array_Of_Threads[Following_Thread-1]->Number_Of_Thread);
    int i = 0;
    while (i < 4)
    {
        if (Array_Of_Threads[i] != NULL)
        {
            if (Array_Of_Threads[i]->status == ready)
            {
                printf("T%d,",Array_Of_Threads[i]->Number_Of_Thread);
            }
        }
		i++;
    }

    if (Array_Of_Threads[i] != NULL)
    {
        if (Array_Of_Threads[i]->status == ready)
        {
            printf("T%d",Array_Of_Threads[i]->Number_Of_Thread);

        }
    }

    printf(" finished->");
    int backspace = 0;
	i = 1;
    while (i < Aggregate_Threads - 1)
    {
        if (Whole_Threads[i]->status == finish)
        {
            printf("T%d,",Whole_Threads[i]->Number_Of_Thread);
            backspace = 1;
        }
		i++;
    }
    if (Whole_Threads[i]->status == finish)
    {
        printf("T%d",Whole_Threads[i]->Number_Of_Thread);
        backspace = 0;
    }
    if (backspace)
        printf("\b ");
    printf("\n");
}

//make sure there's enough space for all the threads
//make sure there's enough space for thread array of size 5
//make sure there's enough space for thread shares
//initialize all threads
//initialize thread array
void Initialization_Of_Thread()
{
    Whole_Threads = malloc(sizeof(Threads*) * (Aggregate_Threads));
    int i = 0;
	while (i < Aggregate_Threads)
	{
        Whole_Threads[i] = malloc(sizeof(Threads));
		i++;
	}
    Array_Of_Threads = malloc(sizeof(Threads*) * 5);
	i = 0;
    while (i < 5)
	{
        Array_Of_Threads[i] = malloc(sizeof(Threads));
		i++;
	}
	i = 0;
    while (i < Aggregate_Threads)
    {
        Whole_Threads[i]->Number_Of_Thread = i;
        Whole_Threads[i]->status = empty;
        Whole_Threads[i]->Index_Of_Thread = -1;
        Whole_Threads[i]->Required_Time_To_Execute = -1;
		i++;
    }
	i = 0;
    while (i < 5)
	{
        Array_Of_Threads[i] = NULL;
		i++;
	}
}

/*
iterate over the entire thread array
iterate over all existing threads
assign the array index and set its readiness status
share the new threads
update totalshare
create context and allocate stack
return error if a thread is not added to the array.
*/
int Creation_Of_Thread()
{
	int i = 0;
    while (i < 5)
    {
        if (Array_Of_Threads[i] == NULL)
        {
		    int j = 1;
            while (j < Aggregate_Threads)
            {

                if (Whole_Threads[j]->status == empty)
                {
                    Whole_Threads[j]->Index_Of_Thread = i;
                    Whole_Threads[j]->status = ready;
                    Array_Of_Threads[i] = Whole_Threads[j];
                    Shares_Of_Threads[i] = Whole_Threads[j]->Required_Time_To_Execute;
                    int temporary = 0;
					int p = 0;
                    while ( p < 5)
                    {
                        temporary += Shares_Of_Threads[p];
						p++;
                    }
                    Sum_Of_Shares = temporary;
                    getcontext(&Whole_Threads[j]->context);
                    Whole_Threads[j]->context.uc_stack.ss_sp = malloc(4096);
                    Whole_Threads[j]->context.uc_stack.ss_size = 4096;
                    makecontext(&Whole_Threads[j]->context, (void*)Run_Thread, 3, Whole_Threads[j]->Number_Of_Thread, Whole_Threads[j]->Required_Time_To_Execute);
                    return 1;
                }
				j++;
            }
        }
		i++;
    }
    return -1;
}

/*
Release the stack and set the status to completed.
Increase the number of finished threads by editing the latest exited thread number.
remove the thread by making the relevant index in the array null.
the matching share index should be set to zero
totalshare array should be updated.
*/
void Leave_Thread(int Number_Of_Thread)
{
    free(Whole_Threads[Number_Of_Thread]->context.uc_stack.ss_sp);
    Whole_Threads[Number_Of_Thread]->status = finish;
    Last_Thread = Number_Of_Thread;
    Number_Of_Finished_Threads++;
    GreenLight = 1;
    Array_Of_Threads[Whole_Threads[Number_Of_Thread]->Index_Of_Thread] = NULL;
    Shares_Of_Threads[Whole_Threads[Number_Of_Thread]->Index_Of_Thread] = 0;
    int temporary = 0;
	int k = 0;
    while (k < 5)
    {
        temporary += Shares_Of_Threads[k];
		k++;
    }
    Sum_Of_Shares = temporary;
    Shortest_Reamining_Time_First();
}
//If it's the final second, turn off the alarm.
//If there is no time left, depart
void Run_Thread(int Number_Of_Thread, int totalDuration)
{
	int i = 1;
    while (i <= totalDuration)
    {
        if (i == totalDuration)
            alarm(0);
			int j = 1;
        while (j < Number_Of_Thread)
		{
            printf("\t");
			j++;
		}
        printf("%d\n", i);
        Whole_Threads[Number_Of_Thread]->Required_Time_To_Execute--;
        sleep(1);
		i++;
	}
    Leave_Thread(Number_Of_Thread);
}


//find the thread that has the shortest remaining time
void ShortestFunction()
{
    int ShortestTime = INT_MAX;
    int ShortestThreadIndex = -1;
	int i = 0;
    while ( i < 5)
    {
        if (Array_Of_Threads[i] != NULL)
        {
            if (ShortestTime > Array_Of_Threads[i]->Required_Time_To_Execute)
            {
                ShortestTime = Array_Of_Threads[i]->Required_Time_To_Execute;
                ShortestThreadIndex = i + 1;
            }
        }
		i++;
    }
    Following_Thread = ShortestThreadIndex;
}

//If the following thread is identical to the previous one, do not transfer context.
//If the next thread differs from the previous one, change context and update the current thread number and next thread status.
void Choose_Following_Thread()
{
    ShortestFunction();
    if (Following_Thread == Current_Thread)
    {
        Print_Function();
        alarm(2);
    }
    else
    {
        if (Array_Of_Threads[Current_Thread-1] != NULL)
            Array_Of_Threads[Current_Thread-1]->status = ready;
        Array_Of_Threads[Following_Thread-1]->status = run;
        Print_Function();
        alarm(2);
        int TempNumber_Of_Thread = Current_Thread;
        Current_Thread = Following_Thread;
        swapcontext(&Array_Of_Threads[TempNumber_Of_Thread-1]->context, &Array_Of_Threads[Following_Thread-1]->context);
    }
}
//switch to main if a thread is executed and exited, also select the following thread
void Shortest_Reamining_Time_First()
{
    if (GreenLight)
    {
        GreenLight = 0;
        getcontext(&Whole_Threads[Last_Thread]->context);
        swapcontext(&Whole_Threads[Last_Thread]->context, &Whole_Threads[0]->context);
    }
    Choose_Following_Thread();
}

int main(int argc, char *argv[])
{
    Aggregate_Threads = argc;
    if (Aggregate_Threads == 1)
    {
        printf("error: Give at least 1 thread.\n");
        return -1;
    }
    int checkArg[argc];
	int i = 0;
    while (i < argc)
    {
        checkArg[i] = strtol(argv[i], NULL, 10);
		i++;
    }
    Initialization_Of_Thread();
	i = 1;
    while (i < Aggregate_Threads)
	{
        Whole_Threads[i]->Required_Time_To_Execute = checkArg[i];
		i++;
	}
    signal(SIGALRM, Shortest_Reamining_Time_First);

    //create threads
  for (int i = 0; i < 5; i++)
    {
        int error = Creation_Of_Thread();
        if (error == -1)
            printf(" Creation_Of_Thread!\n");
    }
    int greatest_common_divisor = Find_Greatest_Common_Divisor(Shares_Of_Threads,5);
    printf("Share:\n");
    for (int i = 0; i < 5; i++)
        printf("%d/%d ", Shares_Of_Threads[i]/greatest_common_divisor, Sum_Of_Shares/greatest_common_divisor);
    printf("\n\nThreads:\n");
    for (int i = 1; i < Aggregate_Threads; i++)
        printf("T%d\t",Whole_Threads[i]->Number_Of_Thread);
    printf("\n");


    //get the starting index,
	//modify Following_Thread
    ShortestFunction();
    Current_Thread = Following_Thread;
    Array_Of_Threads[Following_Thread-1]->status = run;
    Print_Function();
    //get the context of the main and switch it with the next thread
    getcontext(&Whole_Threads[0]->context);
    alarm(2);
    swapcontext(&Whole_Threads[0]->context, &Array_Of_Threads[Following_Thread-1]->context);

    //iterate until all of the threads are executed
	//if there is a waiting thread, insert a new one
    while(Number_Of_Finished_Threads != Aggregate_Threads - 1)
    {
        int error = Creation_Of_Thread();
        ShortestFunction();
            if (Array_Of_Threads[Current_Thread-1] != NULL)
                Array_Of_Threads[Current_Thread-1]->status = ready;
            Array_Of_Threads[Following_Thread-1]->status = run;
            Print_Function();
            alarm(2);
            int TempNumber_Of_Thread = Current_Thread;
            Current_Thread = Following_Thread;
            swapcontext(&Whole_Threads[0]->context, &Array_Of_Threads[Following_Thread-1]->context);
    }

    printf("running-> ready-> finished->");
	i = 1;
    while (i < Aggregate_Threads-1)
	{
        printf("T%d,",Whole_Threads[i]->Number_Of_Thread);
		i++;
	}
    printf("T%d\n",Whole_Threads[i]->Number_Of_Thread);
    printf("END!\n");
    return 0;
}
