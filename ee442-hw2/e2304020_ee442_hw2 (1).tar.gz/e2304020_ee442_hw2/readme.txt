I created 2 different files (lottery & srtf) for 2 different schedulers.
