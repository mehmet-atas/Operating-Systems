#include "queue.h"


//create queues
struct AtomQueue* createQueue(int numberOfQueues, int maxSize)
{
    struct AtomQueue* queues = malloc(sizeof(struct AtomQueue) * numberOfQueues);
    TubeIDs = malloc(sizeof(int)* numberOfQueues);
	int i = 0;
    for (i; i < numberOfQueues; i++)
    {
        TubeIDs[i] = i;
        queues[i].array = malloc(sizeof(struct atom) * maxSize);
        queues[i].maxSize = maxSize;
        queues[i].currentSize = 0;
        queues[i].frontIndex = queues[i].rearIndex = -1;
    }

    return queues;
}

//destroy queues
void *destroyQueue(struct AtomQueue* queues, int numberOfQueues, int maxSize)
{
	int i = 0;
    for (i; i < numberOfQueues; i++)
        free(queues[i].array);
    free(TubeIDs);
    free(queues);
}

// Queue is full
int isFull(struct AtomQueue* queue)
{
    return (queue->maxSize == queue->currentSize);
}

// Queue is empty
int isEmpty(struct AtomQueue* queue)
{
    return (queue->currentSize == 0);
}

// add an item to the queue.
void enqueue(struct AtomQueue* queue, int id, double duration)
{
    //check the queue is full
    if (isFull(queue))
    {
        printf("Queue is already full!\n");
        return;
    }
    //check the queue has an atom

    else if (queue->frontIndex == -1)
    {
        queue->frontIndex = queue->rearIndex = 0;
        queue->array[0].atomID = id;
        queue->array[0].duration = duration;
    }
    //if the queue is completed a circle
    else if (queue->rearIndex == (queue->maxSize - 1) && queue->frontIndex != 0)
    {
        queue->rearIndex = 0;
        queue->array[queue->rearIndex].atomID = id;
        queue->array[queue->rearIndex].duration = duration;
    }

    else
    {
        queue->rearIndex++;
        queue->array[queue->rearIndex].atomID = id;
        queue->array[queue->rearIndex].duration = duration;
    }
    //increase the current size of this queue
    queue->currentSize++;
}

// Function to remove an item from queue.
// It changes front and size
struct atom* dequeue(struct AtomQueue* queue)
{
    //client to be returned
    struct atom* temp;
    //check if the queue is already empty, if yes return
    if (isEmpty(queue))
    {
        printf("Queue is already empty!\n");
        return NULL;
    }
    //find the client in front of the queue and decrement the current size of this queue
    temp = &(queue->array[queue->frontIndex]);
    queue->currentSize--;
    //if the queue is empty, adjust the indexes
    if (isEmpty(queue))
        queue->frontIndex = queue->rearIndex = -1;
    //if the queue completed a circle, adjust front index
    else if (queue->frontIndex == queue->maxSize - 1)
        queue->frontIndex = 0;
    //nothing is unusual
    else
        queue->frontIndex++;
    //return this client
    return temp;
}

//I have checked the website below for the exponential.
//https://stackoverflow.com/questions/34558230/generating-random-numbers-of-exponential-distribution
double exponential(double lambda)
{
    double u = rand() / (RAND_MAX + 1.0);
    return -log(1-u) / lambda;
}
