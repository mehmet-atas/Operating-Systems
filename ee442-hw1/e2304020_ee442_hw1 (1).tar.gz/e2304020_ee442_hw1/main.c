#include <pthread.h>
#include <unistd.h>
#include <malloc.h>
#include <time.h>
#include "queue.h"
#include <stdlib.h>

/*
REFERENCES:
Modern Operating Systems, A. Tanenbaum, Prentice Hall
Unix for Programmers and Users, Graham Glass, Prentice Hall
Video Lectures linked at ODTUclass.
Lecture notes loaded at ODTUclass
https://github.com/efeyitim
https://www.gnu.org/software/libc/manual/html_node/Example-of-Getopt.html
https://www.gnu.org/software/libc/manual/html_node/ISO-C-Mutexes.html
https://www.cs.cmu.edu/afs/cs/academic/class/15492-f07/www/pthreads.html



gcc -o office main.c queue.c -pthread -lm
./office -c 5 -h 10 -o 10 -n 5 -g 100
*/

#define QUEUE_SIZE 4
#define NUM_TUBES 3
#define DURATION_RATE 10.0
#define numberOfQueues 3
int NUM_C = 20;          			 //c input
int NUM_H = 20;			             //h input
int NUM_O = 20;					 	 //o input
int NUM_N = 20;  	    	         //n input
double GENERATION_RATE = 100.0; 	 //g input

int* TubeIDs;                       //detect what is the number of the tube
struct Information info;            //information
pthread_t GeneralThread;            //thread for the generate
pthread_t *TubeThreads;             //thread for every desk
pthread_mutex_t UpdateMutex;        //information structure object is updated
pthread_mutex_t DoneMutex;          //atom is done
pthread_mutex_t *TubeMutexes;       //use for every queue
pthread_cond_t GeneralCond;         //when info is updated send a control signal
pthread_cond_t *TubeConds;          //queue is empty or not
int DoneAtoms = 0;                  //number of atoms leaving
int infoUpdate = 0;                 //info is updated or not
struct AtomQueue* TubeQueues;

//tube thread
void *TubeThread (void *args)
{
    //find the tube number, extract index
    int TubeIndex = *((int*)args);
    //mutex, and cond for individual tubes
    struct AtomQueue *thisTubeQueue = &TubeQueues[TubeIndex];
    pthread_mutex_t *thisTubeMutex = &TubeMutexes[TubeIndex];
    pthread_cond_t *thisTubeCond = &TubeConds[TubeIndex];
    //atom will be dequeued into this variable
    struct atom *DoneAtom;
    //do it until all the atoms are done
    while (DoneAtoms != (NUM_C+NUM_N+NUM_O+NUM_H))
    {
        //lock the tube
        pthread_mutex_lock(thisTubeMutex);
        //wait for wake signal
        while(thisTubeQueue->currentSize == 0)
            pthread_cond_wait(thisTubeCond,thisTubeMutex);
        //unlock the tube
        pthread_mutex_unlock(thisTubeMutex);
        //waiting for serve time
        usleep((unsigned int) (thisTubeQueue->array[thisTubeQueue->frontIndex].duration * 1000000.0));
        //lock the tube again since atom will be removed
        pthread_mutex_lock(thisTubeMutex);
        pthread_mutex_lock(&UpdateMutex);
        //update mutex
        //dequeue
        DoneAtom = dequeue(thisTubeQueue);
        //update info
        info.tubeID = TubeIndex;
        info.myatom.atomID = DoneAtom->atomID;
        info.myatom.atomTYPE = DoneAtom->atomTYPE;
        info.myatom.duration = DoneAtom->duration;
        //send a condition signal
        infoUpdate = 1;
        pthread_cond_signal(&GeneralCond);
        pthread_mutex_unlock(&UpdateMutex);
        pthread_mutex_unlock(thisTubeMutex);
    }

    pthread_exit(NULL);
}

void *GenerateThread (void *args)
{

    while (DoneAtoms != (NUM_C+NUM_N+NUM_O+NUM_H))
    {
        //lock the generate first
        pthread_mutex_lock(&UpdateMutex);
        //update condition signal is asserted
        while (infoUpdate != 1)
        {
            pthread_cond_wait(&GeneralCond,&UpdateMutex);
        }
        printf("Tube %d served Atom %d in %f seconds.\n", info.tubeID, info.myatom.atomID, info.myatom.duration);
        //lock the done mutex,
        pthread_mutex_lock(&DoneMutex);
        DoneAtoms++;
        //unlock the mutex
        pthread_mutex_unlock(&DoneMutex);
        //reset
        infoUpdate = 0;
        //unlock the generate
        pthread_mutex_unlock(&UpdateMutex);
    }
    pthread_exit(NULL);
}


int main(int argc, char *argv[])
{

    int opt;
    while((opt = getopt(argc,argv,"c:h:o:n:g:")) !=-1)
    {
        switch(opt)
        {
            case 'c':
                NUM_C = atoi(optarg);
                break;
            case 'h':
                NUM_H = atoi(optarg);
                break;
            case 'o':
                NUM_O = atoi(optarg);
                break;
            case 'n':
                NUM_N = atoi(optarg);
                break;
            case 'g':
                GENERATION_RATE = atof(optarg);
                break;
        }
    }


    printf("NUM_C      		  : %d\n", NUM_C);
    printf("NUM_H      		  : %d\n", NUM_H);
    printf("NUM_O      		  : %d\n", NUM_O);
    printf("NUM_N      		  : %d\n", NUM_N);
    printf("GENERATION_RATE   : %f\n", GENERATION_RATE);

    //initialize mutexes
    pthread_mutex_init(&DoneMutex, NULL);

    //Create TubeIDs and queues
    TubeQueues = createQueue(NUM_TUBES, QUEUE_SIZE);

    //Create tube threads, mutexes, and conds
    TubeThreads = malloc(sizeof(pthread_t) * NUM_TUBES);
    TubeMutexes = malloc(sizeof(pthread_mutex_t) * NUM_TUBES);
    TubeConds = malloc(sizeof(pthread_cond_t) * NUM_TUBES);
    int i = 0;
    for (i; i < NUM_TUBES ; i++)
    {
        pthread_mutex_init(&(TubeMutexes[i]), NULL);
        pthread_cond_init(&(TubeConds[i]), 0);
		pthread_create(&(TubeThreads[i]), NULL, TubeThread, (void*) &(TubeIDs[i]));
    }

    //Create generate thread, mutex, and cond
    pthread_mutex_init(&UpdateMutex, NULL);
    pthread_cond_init(&GeneralCond, 0);
    pthread_create(&GeneralThread, NULL, GenerateThread, NULL);

    //creating atoms
    int ShortestQueueIndex = 0;                 //the shortest queue index
    int ShortestQueueLength = QUEUE_SIZE;       //he shortest queue length
    unsigned int mainThreadSleepTime = 0;       //main thread sleep time
    double DurationTime = 0;              		//atom duration time

	int C=NUM_C;
   	int H=NUM_H;
    int O=NUM_O;
    int N=NUM_N;
    int CreateAtoms = 0;
    char ptr[20];
    for (CreateAtoms; CreateAtoms < (NUM_C + NUM_H + NUM_O + NUM_N); CreateAtoms++)
    {
    	struct atom myatom;
    	myatom.atomID = CreateAtoms;
    	while(1){
    		int number = rand ();
			number %= 4;

			if ((number == 0) && C!=0) {
			myatom.atomTYPE ='c';
			C--;
			break;
			}
			if ((number == 1) && H!=0) {
			myatom.atomTYPE ='h';
			H--;
			break;
			}
			if ((number == 2) && O!=0) {
			myatom.atomTYPE ='o';
			O--;
			break;
			}
			if ((number == 3) && N!=0) {
			myatom.atomTYPE ='n';
			N--;
			break;
			}

		}
    	ptr[CreateAtoms] = myatom.atomTYPE;

        printf("%c with ID %d is created.\n", myatom.atomTYPE, CreateAtoms);
        mainThreadSleepTime = (unsigned int) (exponential(GENERATION_RATE) * 1000000.0);
        ShortestQueueIndex = 0;
        ShortestQueueLength = QUEUE_SIZE;

		for (i; i < NUM_TUBES; i++)
            pthread_mutex_lock(&TubeMutexes[i]);
		i = 0;
        for (i ; i < NUM_TUBES; i++)
        {

            if (ShortestQueueLength > TubeQueues[i].currentSize)
            {
                ShortestQueueIndex = i;
                ShortestQueueLength = TubeQueues[i].currentSize;
            }
        }

        //unlock the queues
        i = 0;
        for (i; i < NUM_TUBES; i++)
            pthread_mutex_unlock(&TubeMutexes[i]);

        // check there are some empty queues
        if (ShortestQueueLength != QUEUE_SIZE)
        {
            //generate the duration time
            DurationTime = exponential(DURATION_RATE);
            //lock this tube mutex
            pthread_mutex_lock(&TubeMutexes[ShortestQueueIndex]);
            //enqueue this atom
            enqueue(&TubeQueues[ShortestQueueIndex], CreateAtoms, DurationTime);
            //check the queue is empty before
            if (ShortestQueueLength == 0)
                pthread_cond_signal(&TubeConds[ShortestQueueIndex]);
            //unlock the tube
            pthread_mutex_unlock(&TubeMutexes[ShortestQueueIndex]);
        }

        //check all of the queues are full
        else
        {
            //this atom will be discarded
            pthread_mutex_lock(&DoneMutex);
            printf("Atom %d discarded.\n", CreateAtoms);
            DoneAtoms++;
            //unlock the done mutex
            pthread_mutex_unlock(&DoneMutex);
        }
        //main thread waiting for a time
        usleep(mainThreadSleepTime);
    }

    //wait until every atoms leaves
    while(DoneAtoms != (NUM_C + NUM_H + NUM_O + NUM_N));


    //delete threads
    pthread_cancel(GeneralThread);
    i = 0;
    for (i; i < NUM_TUBES; i++)
        pthread_cancel(TubeThreads[i]);

    //destroy all of the mutexes and conds
    pthread_mutex_destroy(&DoneMutex);
    pthread_mutex_destroy(&UpdateMutex);
    i = 0;
    for (i; i < NUM_TUBES; i++)
        pthread_mutex_destroy(&TubeMutexes[i]);

    pthread_cond_destroy(&GeneralCond);
    i = 0;
    for (i; i < NUM_TUBES; i++)
        pthread_cond_destroy(&TubeConds[i]);

    //free dynamic memories
    destroyQueue(TubeQueues, NUM_TUBES, QUEUE_SIZE);
    free(TubeThreads);
}
