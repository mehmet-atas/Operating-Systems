#include <math.h>
#include <stdlib.h>
#include <stdio.h>

extern int* TubeIDs;

struct atom
{
    int atomID;
    char atomTYPE; // C, H, O or N
    double duration;
};

struct tube
{
    int tubeID;
    int tubeTS;         // time stamp (ID of the atom spilled first)
    int moleculeTYPE;   // 1:H2O, 2:CO2, 3: NO2, 4: NH3
};

struct Information
{
    int tubeID;
    struct atom myatom;
};

struct AtomQueue
{
    struct atom *array;
    int maxSize;
    int currentSize;
    int frontIndex;
    int rearIndex;
};

struct AtomQueue* createQueue(int numberOfQueues, int maxSize);
void *destroyQueue(struct AtomQueue* queues, int numberOfQueues, int maxSize);
int isFull(struct AtomQueue* queue);
int isEmpty(struct AtomQueue* queue);
void enqueue(struct AtomQueue* queue, int id, double duration);
struct atom* dequeue(struct AtomQueue* queue);
double exponential(double lambda);
