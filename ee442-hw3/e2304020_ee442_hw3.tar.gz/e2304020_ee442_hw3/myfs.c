#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char* disk;
char buffer[512];

FILE* fin;
FILE* fout;

typedef struct{
    char naming[248];
    int firstChunk;
    int capacity;

} FL;

typedef struct{
    int FileAllocationTable[4096];
    FL listing[128];
} head;

typedef struct{
    head head;
    char Info[4096][512];
} FileSystem;

FileSystem FS;

struct FAT
{
    int ENTRY;
};

struct FileList
{
    char fname[248];
    int fblock;
    int fsize;
};

struct Data
{
    char data[512];
};


int ConvertEndian(int num)
{
    return ((num>>24)&0xff) | ((num<<8)&0xff0000) | ((num>>8)&0xff00) | ((num<<24)&0xff000000); 
}
/*
-Initialize FAT
-To save space, just the first byte of the file name is written with special byte NULL rather than clearing all 248 name bytes.
-When a new file is written to the matching block, the name bytes will be cleared and written with a new name.
-Clear File List
-Write formatted file
*/
void Format(char *diskimage){
    
    for(int i=1; i<4096; i++){    
        FS.head.FileAllocationTable[i] = 0;
    }

    char empty_nameofFile = 0x0;    //
    for(int i=0; i<128; i++){
        
        FS.head.listing[i].naming[0] = empty_nameofFile;
        FS.head.listing[i].firstChunk = 0;
        FS.head.listing[i].capacity = 0;
    }
    FILE *fout; 
    fout = fopen(diskimage,"r+");
    if(fout != NULL){
        fwrite(&FS.head, sizeof(FS.head), 1, fout);
    }
}

/*
-clear the buffer first
-Open the source file and set the current pointer 
-Read from source to buffer and find empty space
-Contcanate strings and ppen destination file
-Store how many bytes are read
-Searching for an empty block if whole chunk is read
-Find empty list index and reposition the cursor in order to write to data
-Update first block information and update file name information
-Calculate the total size and reposite the cursor to the beginning of the file
*/
void Write(char *diskimage, char *SourcePath, char *DestinationFile)
{
	int ListIndex = -1;
    int CurrentIndex = -1;
    int PreviousIndex = 1;
    int endian = -1;
    int counter = 0;
    int number = 1;
	int firstChunk;
    int previous_block;
    char list_index;
    char first = 1;
fin = fopen(SourcePath, "r+"); 
    
    fseek(fin, 0, SEEK_SET);    
    if(fin == NULL){
        FILE *dest;
        char d[256] = "";
        strcat(d,"./disk.image/");
        strcat(d, DestinationFile);   
        dest = fopen(d, "w+");     
        fseek(dest, 0, SEEK_SET);
        size_t count;  
        while((count = fread(buffer, 1, sizeof(buffer), fin)) > 0){
            
            int FAT_index = 0;
            if(count > 0){      
                for(int i=0; i<4096; i++){   
                    if(FS.head.FileAllocationTable[i] == 0){
                        FAT_index = i;
                        break;
                    }
                }
                if(FAT_index != 0){    
                    if(first == 1){ 
                        firstChunk = FAT_index;
                        for(int j=0; j<128; j++){     
                            if(FS.head.listing[j].firstChunk == 0){
                                list_index = j;
                                break;
                            }
                        }
                        FS.head.listing[list_index].firstChunk = firstChunk;     
                        for(int m=0; m<strlen(DestinationFile); m++){      
                            FS.head.listing[list_index].naming[m] = DestinationFile[m];
                        }
                        FS.head.listing[list_index].naming[strlen(DestinationFile)] = '\0';     
                        
                        first = 0;
                        previous_block = FAT_index;
                    }
		}
		}
		}
}
	
    struct FAT FAT[4096];
    struct FileList FileList[128];
    struct Data Data[4096];
	FILE *FilePointer = fopen(diskimage, "r+");
    FILE *SourcePointer = fopen(SourcePath, "r+");
    fread(FAT, sizeof(FAT), 1, FilePointer);
    fread(FileList, sizeof(FileList), 1, FilePointer);
    fread(Data, sizeof(Data), 1, FilePointer);

    int i=0;
    while(i<128){
		if(strcmp(FileList[i].fname,DestinationFile) == 0)
        {
            printf("The same name already exists!\n");
            return;
        }
        i++;
    }
   
    while (1)
    {
        memset(&buffer[0], 0, sizeof(buffer));

        //
        number = fread(buffer, sizeof(char), sizeof(buffer), SourcePointer);

        //
        i = PreviousIndex;
        while(i<4096){
            if (FAT[i].ENTRY == 0)
                break;
            i++;
        }
      
        CurrentIndex = i;
        fseek(FilePointer, CurrentIndex * sizeof(int), SEEK_SET);
        endian = ConvertEndian(CurrentIndex);
        FAT[CurrentIndex].ENTRY = 0xFFFFFFFF;
        if (counter == 0)
        {
            fseek(FilePointer, 4096 * sizeof(struct FAT) + 128 * sizeof(struct FileList) + CurrentIndex * sizeof(struct Data), SEEK_SET);
            fwrite(&buffer, sizeof(char), number, FilePointer);
            int j=0;
            while(j<128){
                if (FileList[j].fblock == 0 && FileList[j].fsize == 0)
                    break;
                j++;
            }          
            ListIndex = j;
            strcpy(&FileList[ListIndex].fname[0], DestinationFile);
            FileList[ListIndex].fblock = CurrentIndex;
        }
        
        else
        {
            FAT[PreviousIndex].ENTRY = endian;
            fseek(FilePointer, 4096 * sizeof(struct FAT) + 128 * sizeof(struct FileList) + CurrentIndex * sizeof(struct Data), SEEK_SET);
            fwrite(&buffer, sizeof(char), number, FilePointer);
        }
        PreviousIndex = CurrentIndex;
        counter++;
        if (number != sizeof(buffer))
            break;
    }
    int TotalSize = 512 * (counter - 1) + number;  
    FileList[ListIndex].fsize = TotalSize;
    fseek(FilePointer, 0, SEEK_SET);
    fwrite(FAT, sizeof(FAT), 1, FilePointer);
    fwrite(FileList, sizeof(FileList), 1, FilePointer);
    fclose(FilePointer);
    fclose(SourcePointer);
}
/*
-read fat and filelist also do find the file
-create new file and read until the end is reached
-reset the buffer first and find the following fat index
*/
void Read(char *diskimage, char *SourceFile, char *DestinationPath)
{
  
    struct FAT FAT[4096];
    struct FileList FileList[128];
    struct Data Data[4096];
    FILE *FilePointer;
    FILE *fileRead;
    FilePointer = fopen(diskimage, "r+");
    fread(FAT, sizeof(FAT), 1, FilePointer);
    fread(FileList, sizeof(FileList), 1, FilePointer);
    fread(Data, sizeof(Data), 1, FilePointer);

    int i=0;
    while(i<128){
            if(strcmp(FileList[i].fname,SourceFile) == 0)
			break;
        i++;
    }

    char match = 0;      
    for(int i=0; i<128; i++){
        if(strcmp(FS.head.listing[i].naming, SourceFile) == 0){
            match = 1;
            break;
        }
    }
    if(match == 1){
        FILE *box;
        char np[256] = "";
        strcat(np,"./disk.image/");
        strcat(np, SourceFile);
        box = fopen(np, "r");     
        fseek(box, 0, SEEK_SET);
        if(box != NULL){
            FILE *d;
            d = fopen(DestinationPath, "w+");    
            fseek(d, 0, SEEK_SET);
            if(d != NULL){
                int offset = 0;
                size_t count;
                while((count = fread(&buffer, 1, sizeof(buffer), box)) > 0){    
                    if(count == 512){
                        fwrite(&buffer, sizeof(buffer), 1, d);
                        offset += 512;
                        fseek(box, offset, SEEK_SET);
                        fseek(d, offset, SEEK_SET);
                    }else{
                        fwrite(&buffer, count, 1, d);
                        fclose(d);
                        fclose(box);
                    }
                }
            }
        }
    }

    fileRead = fopen(DestinationPath, "w+");
    int index = FileList[i].fblock;
    int size = FileList[i].fsize;

    while (1)
    {
        //
        memset(&buffer[0], 0, sizeof(buffer));
        memcpy(&buffer, &Data[index], sizeof(Data[index]));
        if (size > 512)
        {
            size = size - 512;
            fwrite(buffer, 512 * sizeof(char), 1, fileRead);
        }
        else
            fwrite(buffer, size * sizeof(char), 1, fileRead);
        if (FAT[index].ENTRY == 0xFFFFFFFF) 
            break;
        index = ConvertEndian(FAT[index].ENTRY);
    }
    fclose(FilePointer);
    fclose(fileRead);
}
/*
-Clear the file_list entry of deleted file
-Clear the FAT entry of deleted file
-Delete file name, first block, file size
-Delete data and FAT
-Reposite the cursor to the beginning of the file
*/
void Delete(char *diskimage, char *filename)
{

    struct FAT FAT[4096];
    struct FileList FileList[128];
    struct Data Data[4096];
    FILE *FilePointer;
    FilePointer = fopen(diskimage, "r+");
    fread(FAT, sizeof(FAT), 1, FilePointer);
    fread(FileList, sizeof(FileList), 1, FilePointer);
    fread(Data, sizeof(Data), 1, FilePointer);
    int index=0;
    while(index<128){
        if(strcmp(FileList[index].fname, filename) == 0)
	break;
        index++;
    }

	int firstChunk = FS.head.listing[index].firstChunk;    
    FS.head.listing[index].naming[0] = 0;
    FS.head.listing[index].capacity = 0;
    FS.head.listing[index].firstChunk = 0;
    int following= 0;  
    int key = firstChunk;
    while(following != 0xFFFFFFFF){
        following = FS.head.FileAllocationTable[key];
        FS.head.FileAllocationTable[key] = 0;
        key = following;
    }
	FILE *folder;  
	folder = fopen("./disk.image/", "w+"); 
    if(folder != NULL){
        fwrite(&FS.head, sizeof(FS.head), 1, folder);
	}

    memset(&FileList[index].fname[0], 0, sizeof(FileList[index].fname));
    int indexo = FileList[index].fblock;
    FileList[index].fblock = 0;
    int size = FileList[index].fsize;
    FileList[index].fsize = 0;
    int temp = -1;
    while (1)
    {
        memset(&Data[indexo].data[0], 0, sizeof(Data[indexo].data));
        if (FAT[indexo].ENTRY == 0xFFFFFFFF) 
            break;
        temp = ConvertEndian(FAT[indexo].ENTRY);
        FAT[indexo].ENTRY = 0; 
        indexo = temp;
    }
    FAT[indexo].ENTRY = 0;
    fseek(FilePointer, 0, SEEK_SET);
    fwrite(FAT, sizeof(FAT), 1, FilePointer);
    fwrite(FileList, sizeof(FileList), 1, FilePointer);
    fwrite(Data, sizeof(Data), 1, FilePointer);
    fclose(FilePointer);  
}

/*
-set the cursor
-file name and file size and first block index
-print if there is a file
*/
void List(char *diskimage)
{
    struct FileList File;
    FILE *FilePointer;
    FilePointer = fopen(diskimage,"r");
    fseek(FilePointer, 4096 * sizeof(struct FAT), SEEK_SET);
    printf("file name\t\tfile size\tfirst block index\n");
	int i = 0;
    while (i < 128)
    {
        fread(&File, sizeof(File), 1, FilePointer);
        if (( File.fsize != 0) && File.fname[0] != '.')
            printf("%-15s\t\t%-10d\t%-10d\n", File.fname, File.fsize, File.fblock);
	i++;
    }
	int k=0;
	int j=0;
	for(k;k< 128; k++){
        if(FS.head.listing[i].capacity > 0){
            printf("%s", FS.head.listing[k].naming);
            for(j; j<(32-strlen(FS.head.listing[k].naming)); j++){
                printf(" ");
            }
            printf("%d\n", FS.head.listing[k].capacity);
        }
    }
    fclose(FilePointer);
}

/*
-read fat and filelist
-create new data structures after defragment
-get the firstblock index
-copy the corresponding data and 
-copy the corresponding fat with the new fat ENTRY
*/

void Defragment(char *diskimage)
{	
	int numeral = 0;
 	char callstring[256] = "";
    strcat(callstring,"./disk.image/"); 
    
    for(int i=0;i<128;i++){
        if(FS.head.listing[i].naming[0]!=0){
            numeral++;
        }
    }
    FILE *fileArray[numeral];
    char name[numeral][256];
    FILE *DestinationArray;
    int var=0;
    char thing;

    for(int i=0;i<128;i++){
       
        if(FS.head.listing[i].naming[0]!= 0){    
        strcat(callstring, FS.head.listing[i].naming);
        DestinationArray = fopen(callstring, "r");
        
        strcpy(name[var],FS.head.listing[i].naming); 
        fileArray[var] = fopen(name[var], "w");

        
        thing = fgetc(DestinationArray);      
        while (thing != EOF)
         {
        fputc(thing, fileArray[var]);   
        thing = fgetc(DestinationArray);
        }

        fclose(fileArray[var]);
        fclose(DestinationArray);
        var++;
        }
    }
	int FATindex = 1;
    int preindex = 1;
    int index;
    int flag = 1;
    struct FAT FAT[4096];
    struct FileList FileList[128];
    struct Data Data[4096];
    FILE *FilePointer = fopen(diskimage, "r+");
    fread(FAT, sizeof(FAT), 1, FilePointer);
    fread(FileList, sizeof(FileList), 1, FilePointer);
    fread(Data, sizeof(Data), 1, FilePointer);
    struct FAT recentFAT[4096];
    struct FileList recentFileList[128];
    struct Data recentData[4096];
    recentFAT[0].ENTRY = 0xFFFFFFFF;

    int i;
    int j;
    for (i = 0, j = 0; i < 128; i++)
    {
        if (FileList[i].fsize != 0 && FileList[i].fblock != 0)
        {
            memcpy(&recentFileList[j], &FileList[i], sizeof(struct FileList));
            recentFileList[j].fblock = FATindex;
            j++;
            index = FileList[i].fblock;
            while (1)
            {
                memcpy(&recentData[FATindex], &Data[index], sizeof(struct Data));
                if (flag)
                {
                    recentFAT[preindex].ENTRY = 0xFFFFFFFF;
                    flag = 0;
                }
                else
                    recentFAT[preindex].ENTRY = ConvertEndian(FATindex);

                preindex = FATindex;
                if (FAT[index].ENTRY == 0xFFFFFFFF)
                {
                    recentFAT[FATindex].ENTRY = 0xFFFFFFFF;
                    FATindex++;
                    flag = 1;
                    break;
                }
                FATindex++;
                index = ConvertEndian(FAT[index].ENTRY);
            }
        }
    }
    if (j == 0)
    {
        printf("The disk is already empty!\n");
        return;
    }
    fseek(FilePointer, 0, SEEK_SET);
    fwrite(recentFAT, sizeof(recentFAT), 1, FilePointer);
    fwrite(recentFileList, sizeof(recentFileList), 1, FilePointer);
    fwrite(recentData, sizeof(recentData), 1, FilePointer);
    fclose(FilePointer);  
}

//prints all the Filelist
//find the file and print it
void PrintingFileList(char *diskimage)
{
    struct FileList FileList[128];
    FILE *FilePointer;
    FilePointer = fopen(diskimage, "r");
    fseek(FilePointer, 4096 * sizeof(struct FAT), SEEK_SET);
    fread(FileList, sizeof(FileList), 1, FilePointer);
    FILE *fptr = fopen("printfilelist.txt", "w");
    int i;
    for (i = 0; i < 128; i++)
    {
        fprintf(fptr,"%-10s\t%-10d\t%-10d\n",FileList[i].fname, FileList[i].fblock, FileList[i].fsize);
    }
    fclose(fptr);
    fclose(FilePointer);
}



//prints all the fat
void PrintingFAT(char *diskimage)
{
    struct FAT FAT[4096];
    FILE *FilePointer;
    FilePointer = fopen(diskimage, "r");
    fread(FAT, sizeof(FAT), 1, FilePointer);
    int i,j;
    FILE *fptr = fopen("fat.txt", "w");
    for(j=0; j<4096 ;){
    	for(i=0; i<4 ; i++){
    		fprintf(fptr,"%-10d\t0x%-10.8x\t", j+i, FAT[j+i].ENTRY);
    	}
    	j+=4;
    fprintf(fptr,"\n");
    }
    fclose(fptr);
    fclose(FilePointer);
}

int main(int argc, char *argv[])
{
 disk = argv[1]; 
 fin = fopen("./disk.image/","rb");                                                   
    if(fin != NULL){    
		while(fread(&FS.head, sizeof(FS.head), 1, fin));  //If exists, read info and store it in FS.head structure
		fclose(fin);
    }
	else{
		FS.head.FileAllocationTable[0] = 0xFFFFFFFF; 
        FS.head.listing[0].naming[0] = 0;
        FS.head.listing[0].capacity = 0;
        FS.head.listing[0].firstChunk = 0;
		int i=1;
        while(i<4096){
            FS.head.FileAllocationTable[i] = 0;
            FS.head.listing[i].naming[0] = 0;
            FS.head.listing[i].capacity = 0;
            FS.head.listing[i].firstChunk = 0;
			 i++;
        }

        fout = fopen("./disk.image/", "w+");    
        if(fout != NULL){   
            fwrite(&FS.head, sizeof(FS.head), 1, fout);
            fclose(fout);
        }
    }
	if(strcmp(argv[2], "-format") == 0)
		Format(argv[1]);
	else if(strcmp(argv[2], "-write") == 0)
		Write(argv[1], argv[3], argv[4]);
	else if(strcmp(argv[2], "-read") == 0)
		Read(argv[1], argv[3], argv[4]);
	else if(strcmp(argv[2], "-list") == 0)
		List(argv[1]);
	else if(strcmp(argv[2],"-delete") == 0)
		Delete(argv[1], argv[3]);
	else if(strcmp(argv[2],"-defragment") == 0)
		Defragment(argv[1]);
	else if(strcmp(argv[2],"-printfilelist") == 0)
		PrintingFileList(argv[1]);
	else if(strcmp(argv[2],"-printfat") == 0)
		PrintingFAT(argv[1]);
    else
        printf("Unknown input.\n");
	return 0;
}

